BEDENG BIRU SUKASARI - PROYEK ANDROID WEBVIEW
============================================

Aplikasi Android ini membuka website produksi:
https://cctvpalembangmurah.com/bd/

Fitur:
- Ikon aplikasi khusus bernuansa rumah, biru navy, dan emas.
- Login dan data tetap menggunakan website/database hosting.
- JavaScript dan DOM storage aktif untuk mendukung aplikasi PHP.
- Cookie aktif agar sesi login berjalan.
- Tautan WhatsApp/telepon/email dibuka melalui aplikasi Android yang sesuai.
- Pemilih file tersedia untuk upload gambar barcode/QRIS dari halaman web.
- Tombol Back Android menavigasi halaman sebelumnya.
- Hanya HTTPS untuk website; error sertifikat tidak dilewati.

CARA MEMBUAT APK DI ANDROID STUDIO
1. Instal Android Studio versi terbaru dan Android SDK Platform 35.
2. Ekstrak folder proyek ini.
3. Buka Android Studio > Open > pilih folder BedengBiruSukasari.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Build-Tools.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
7. Untuk distribusi resmi, pilih Build > Generate Signed Bundle / APK dan buat keystore sendiri. Simpan keystore dan password dengan aman.

PENTING
- Proyek ini adalah source Android Studio, bukan file APK yang sudah dikompilasi.
- Build APK perlu Android Studio/SDK pada komputer.
- Aplikasi memerlukan internet dan website hosting aktif.
- Fitur kamera, notifikasi push, dan kerja offline belum ditambahkan.
- Untuk upload QRIS, pemilih file Android didukung.
- WhatsApp harus terpasang atau tersedia aplikasi/link handler yang sesuai.

CARA BUILD APK OTOMATIS MELALUI GITHUB ACTIONS
1. Buat repository baru di https://github.com (misalnya bedeng-biru-sukasari-android).
2. Ekstrak ZIP ini di komputer.
3. Upload SELURUH ISI folder bedeng_android ke repository GitHub (termasuk folder tersembunyi .github/workflows).
   Cara termudah: gunakan GitHub Desktop, pilih Add Existing Repository, lalu Publish Repository.
4. Setelah file masuk ke branch main, buka tab Actions di repository.
5. Pilih workflow "Build BEDENG BIRU SUKASARI APK". Jika belum berjalan otomatis, klik Run workflow.
6. Tunggu sampai proses selesai dengan tanda hijau (Success).
7. Buka hasil run, cari bagian Artifacts, lalu unduh BEDENG-BIRU-SUKASARI-APK.
8. Ekstrak file artifact ZIP; di dalamnya terdapat app-debug.apk. Salin ke HP Android dan instal.

CATATAN KEAMANAN
- APK debug untuk uji coba; Android mungkin meminta izin "Install unknown apps".
- Jangan unggah keystore, password, token Fonnte, atau file konfigurasi rahasia ke repository publik.
- Untuk distribusi Play Store/produksi, buat APK release bertanda tangan dengan keystore privat.
- Workflow ini membangun APK dari source; proses build berjalan di GitHub, bukan di chat.
